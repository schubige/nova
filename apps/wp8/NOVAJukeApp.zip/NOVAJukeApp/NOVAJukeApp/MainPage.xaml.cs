﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using System.Text;
using System.Net.Sockets;
using System.IO.IsolatedStorage;
using System.Threading;
using Windows.Foundation;
using Windows.Storage.Streams;
using System.Windows.Media;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;
using Microsoft.Phone.Tasks;
using Coding4Fun.Toolkit.Controls;
using NOVAJukeApp.Resources;

namespace NOVAJukeApp
{
    public partial class MainPage : PhoneApplicationPage
    {
        public class Communicator
        {
            Socket _socket = null;
            static ManualResetEvent _done = new ManualResetEvent(false);
            const int MaxWait = 5000;
            const int MaxLen = 2048;
            public Communicator()
            {
            }

            public SocketError Connect(string hostId, int port)
            {
                SocketError res = SocketError.ConnectionReset;
                DnsEndPoint host = new DnsEndPoint(hostId, port);
                _socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                SocketAsyncEventArgs context = new SocketAsyncEventArgs();
                context.RemoteEndPoint = host;
                context.Completed += new EventHandler<SocketAsyncEventArgs>(delegate(object s, SocketAsyncEventArgs e)
                {
                    res = e.SocketError;
                    _done.Set();
                });
                _done.Reset();
                _socket.ConnectAsync(context);
                _done.WaitOne(MaxWait);
                return res;
            }
            public SocketError Send(string data)
            {
                SocketError res = SocketError.TimedOut;
                SocketAsyncEventArgs context = new SocketAsyncEventArgs();
                context.RemoteEndPoint = _socket.RemoteEndPoint;
                context.UserToken = null;
                context.Completed += new EventHandler<SocketAsyncEventArgs>(delegate(object s, SocketAsyncEventArgs e)
                {
                    res = e.SocketError; _done.Set();
                });
                byte[] payload = Encoding.UTF8.GetBytes(data);
                context.SetBuffer(payload, 0, payload.Length);
                _done.Reset();
                _socket.SendAsync(context);
                _done.WaitOne(MaxWait);
                return res;
            }
            public string Receive()
            {
                string res = "Operation Timeout";
                SocketAsyncEventArgs context = new SocketAsyncEventArgs();
                context.RemoteEndPoint = _socket.RemoteEndPoint;
                context.SetBuffer(new Byte[MaxLen], 0, MaxLen);
                context.Completed += new EventHandler<SocketAsyncEventArgs>(delegate(object s, SocketAsyncEventArgs e)
                {
                    if (e.SocketError == SocketError.Success)
                    {
                        res = Encoding.UTF8.GetString(e.Buffer, e.Offset, e.BytesTransferred);
                        res = res.Trim('\0');
                    }
                    else
                    {
                        res = e.SocketError.ToString();
                    }
                    _done.Set();
                });
                _done.Reset();
                _socket.ReceiveAsync(context);
                _done.WaitOne(MaxWait);
                return res;
            }
            public void Close()
            {
                if (_socket != null)
                {
                    _socket.Close();
                }
            }
        }
        Communicator me = new Communicator();
        bool connected = false;
        List<string> menu;
        public MainPage()
        {
            InitializeComponent();
            List<string> menu = new List<string>();
            selector.ItemsSource = menu;

            string HOST = "terra-nova.inf.ethz.ch";
            int PORT = 55555;

            SocketError res = me.Connect(HOST, PORT);
            if (res == SocketError.Success)
            {
                string[] animNames = me.Receive().Split(',');
                foreach (string name in animNames) menu.Add(name);
                connected = true;
            }
            else
            {
                MessageBox.Show("Unable to connect to NOVA (" + HOST + ":" + PORT + ":" + res + ")", "NOVA Jukebox", MessageBoxButton.OK);
                IsolatedStorageSettings.ApplicationSettings.Save();
                Application.Current.Terminate();
            }
    
        }
        private void col_ColorChanged(object sender, Color col)
        {
            Send("col", col);
        }
        private void lum_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Send("lum", e.NewValue);
        }
        private void vel_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Send("vel", e.NewValue);
        }

        private void Send(String key, double value)
        {
            if (connected) me.Send(key + ((byte)(value * 255.0)).ToString("X2") + ",");
        }

        private void Send(String key, Color value)
        {
            if (connected)
            {
                me.Send(key + value.R.ToString("X2") + value.G.ToString("X2") + value.B.ToString("X2") + ",");
            }
        }

        private void Send(String key, String value)
        {
            if (connected)
            {
                me.Send(key + value + ",");
            }
        }

        private void LongListSelector_SelectionChanged_2(object sender, SelectionChangedEventArgs e)
        {
                foreach (string a in e.AddedItems) Send("anim",a);
        }
    }
}